﻿// imgUtils.cpp : 定义静态库的函数。
//

#include "pch.h"
#include "framework.h"

// #include <iostream>
//#define _USE_MATH_DEFINES
//#include<math.h>
#include<iostream>
#include<fstream>
#include<vector>

#include<opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
#include "opencv2/imgproc.hpp"

#include "opencv2/imgcodecs.hpp"
#include "opencv2/highgui.hpp"

#include "imgUtils.h"



using namespace cv;

float PIX_STD = 200.0;
float SCALE_FACTOR = 1.35;

namespace ImgUtils
{
	cv::Point2f affine_transform(cv::Point2f pt, cv::Mat &t)
	{
		Mat new_pt(3, 1, CV_32FC1, Scalar::all(1));
		new_pt.at<float>(0, 0) = pt.x;
		new_pt.at<float>(1, 0) = pt.y;
		// Point3f new_pt = Point3f(pt.x, pt.y, 1.f);
		new_pt = t * new_pt;  // shape (3, 1)

		Point2f output_pt(new_pt.at<float>(0, 0), new_pt.at<float>(1, 0));
		return output_pt;
	}

	// output_size (w, h)
	Mat get_affine_transform(Point2f center, Point2f scale, float rot, int *output_size, Point2f shift, bool inv)
	{
		Point2f scale_tmp = scale * PIX_STD;
		float src_w = scale_tmp.x;
		float dst_w = static_cast<float>(output_size[0]);
		float dst_h = static_cast<float>(output_size[1]);

		float rot_rad = CV_PI * rot / 180.f;
		Point2f temp_dir = Point2f(0.f, src_w * -0.5);
		Point2f src_dir = get_dir(Point2f(0.f, src_w * -0.5), rot_rad);
		Point2f dst_dir(0.f, dst_w * -0.5);

		Point2f src[3];
		Point2f dst[3];

		src[0] = center + Point2fMul(scale_tmp, shift);
		src[1] = center + src_dir + Point2fMul(scale_tmp, shift);

		dst[0] = Point2f(dst_w * 0.5, dst_h * 0.5);
		dst[1] = Point2f(dst_w * 0.5, dst_h * 0.5) + dst_dir;

		src[2] = get_3rd_point(src[0], src[1]);
		dst[2] = get_3rd_point(dst[0], dst[1]);

		Mat_<float> trans;
		if (inv)
		{
			trans = getAffineTransform(dst, src);
		}
		else
		{
			trans = getAffineTransform(src, dst);
		}

		//trans[0][0] = -trans[0][0];
		//trans[1][1] = -trans[1][1];
		return trans;
	}

	Mat crop(Mat &img, Point2f center, Point2f scale, int *output_size, float rot)
	{
		Mat trans = get_affine_transform(center, scale, rot, output_size, Point2f(0.f, 0.f), false);
		Mat dst_img = Mat::zeros(output_size[1], output_size[0], img.type());

		warpAffine(img, dst_img, trans, dst_img.size());

		return dst_img;
	}

	Mat crop_by_trans(Mat &img, Mat &trans, int *output_size)
	{
		Mat dst_img = Mat::zeros(output_size[1], output_size[0], img.type());

		warpAffine(img, dst_img, trans, dst_img.size());

		return dst_img;
	}

	Point2f get_dir(Point2f src_point, float rot_rad)
	{
		float sn = sin(rot_rad);
		float cs = cos(rot_rad);
		// float sn, cs = sin(rot_rad), cos(rot_rad);

		Point2f src_result(0.f, 0.f);
		src_result.x = src_point.x * cs - src_point.y * sn;
		src_result.y = src_point.y * sn + src_point.y * cs;

		return src_result;
	}

	std::vector<Point2f> pts2cs(Mat_<float> &pts)
	{
		std::vector<Point2f> output_vec;

		Rect bbox = boundingRect(pts);
		float x_min = bbox.x;
		float y_min = bbox.y;
		float x_max = bbox.x + bbox.width;
		float y_max = bbox.y + bbox.height;

		auto center_w = (floor(x_min) + ceil(x_max)) / 2.0f;
		auto center_h = (floor(y_min) + ceil(y_max)) / 2.0f;

		float scale = max(ceil(x_max) - floor(x_min), ceil(y_max) - floor(y_min)) / PIX_STD;
		//scale *= SCALE_FACTOR;

		Point2f scale_pts(scale, scale);
		Point2f center(center_w, center_h);

		output_vec.push_back(center);
		output_vec.push_back(scale_pts);

		return output_vec;
	}

	Mat ConvertMat2CHW(Mat &input_img)
	{
		auto size = input_img.size();
		cv::Size newsize(size.width, size.height * input_img.channels());
		cv::Mat frameCHW(newsize, CV_32FC1);
		for (int i = 0; i < input_img.channels(); ++i)
		{
			cv::extractChannel(
				input_img,
				cv::Mat(
					size.height,
					size.width,
					CV_32FC1,
					&(frameCHW.at<float>(size.height*size.width*i))),
				i);
		}

		return frameCHW;
	}

	inline Point2f get_3rd_point(Point2f a, Point2f b)
	{
		Point2f direct = a - b;
		Point2f output = b + Point2f(-direct.y, direct.x);

		return output;
	}

	inline Point2f Point2fMul(Point2f a, Point2f b)
	{
		Point2f output_pt(a.x * b.x, a.y * b.y);

		return output_pt;
	}

	// Checks if a matrix is a valid rotation matrix.
	bool isRotationMatrix(Mat &R)
	{
		Mat Rt;
		transpose(R, Rt);
		Mat shouldBeIdentity = Rt * R;
		Mat I = Mat::eye(3, 3, shouldBeIdentity.type());

		return  norm(I, shouldBeIdentity) < 1e-6;

	}

	// Calculates rotation matrix to euler angles
	// The result is the same as MATLAB except the order
	// of the euler angles ( x and z are swapped ).
	Vec3f rotationMatrixToEulerAngles(Mat &R)
	{

		assert(isRotationMatrix(R));

		float sy = sqrt(R.at<float>(0, 0) * R.at<float>(0, 0) + R.at<float>(1, 0) * R.at<float>(1, 0));

		bool singular = sy < 1e-6; // If

		float x, y, z;
		if (!singular)
		{
			x = atan2(R.at<float>(2, 1), R.at<float>(2, 2));
			y = atan2(-R.at<float>(2, 0), sy);
			z = atan2(R.at<float>(1, 0), R.at<float>(0, 0));
		}
		else
		{
			x = atan2(-R.at<float>(1, 2), R.at<float>(1, 1));
			y = atan2(-R.at<float>(2, 0), sy);
			z = 0;
		}
		return Vec3f(x, y, z);

	}

	// Calculates rotation matrix given euler angles.
	Mat eulerAnglesToRotationMatrix(Vec3f &theta)
	{
		// Calculate rotation about x axis
		Mat R_x = (Mat_<double>(3, 3) <<
			1, 0, 0,
			0, cos(theta[0]), -sin(theta[0]),
			0, sin(theta[0]), cos(theta[0])
			);

		// Calculate rotation about y axis
		Mat R_y = (Mat_<double>(3, 3) <<
			cos(theta[1]), 0, sin(theta[1]),
			0, 1, 0,
			-sin(theta[1]), 0, cos(theta[1])
			);

		// Calculate rotation about z axis
		Mat R_z = (Mat_<double>(3, 3) <<
			cos(theta[2]), -sin(theta[2]), 0,
			sin(theta[2]), cos(theta[2]), 0,
			0, 0, 1);


		// Combined rotation matrix
		Mat R = R_z * R_y * R_x;

		return R;

	}


	/*class PoseEstimator*/
	PoseEstimator::PoseEstimator(int * img_size, std::string model_file_name)
	{
		this->size[0] = img_size[0];
		this->size[1] = img_size[1];

		this->model_points_68 = this->_get_full_model_points(model_file_name);

		this->focal_length = this->size[1];
		this->camera_center[0] = this->size[0] / 2;
		this->camera_center[1] = this->size[1] / 2;
		this->camera_matrix = Mat_<float>(3, 3, 0.f);
		this->camera_matrix[0][0] = this->focal_length;
		this->camera_matrix[0][2] = this->camera_center[0];
		this->camera_matrix[1][1] = this->focal_length;
		this->camera_matrix[1][2] = this->camera_center[1];
		this->camera_matrix[2][2] = 1.f;

		this->dist_coeffs = Mat_<float>(4, 1, 0.f);
		
		//float r_vec_arr[3] = { 0.01891013f, 0.08560084f, -3.14392813f };
		//float t_vec_arr[3] = { -14.97821226f,-10.62040383f,-2053.03596872f };
		//this->r_vec = Mat_<float>(3, 1, r_vec_arr);
		//this->t_vec = Mat_<float>(3, 1, t_vec_arr);

		this->r_vec = Mat_<float>(3, 1);
		this->t_vec = Mat_<float>(3, 1);

		this->r_vec[0][0] = 0.01891013f;
		this->r_vec[1][0] = 0.08560084f;
		this->r_vec[2][0] = -3.14392813f;

		this->t_vec[0][0] = -14.97821226f;
		this->t_vec[1][0] = -10.62040383f;
		this->t_vec[2][0] = -2053.03596872f;

	}

	std::vector<Mat_<float>> PoseEstimator::solve_pose_by_68_points(Mat_<float> &image_points)
	{
		std::vector<Mat_<float>> vec_mat;
		//Mat_<float> r_vec;
		//Mat_<float> t_vec;
		solvePnP(this->model_points_68, image_points, this->camera_matrix, this->dist_coeffs, this->r_vec, this->t_vec, true);

		vec_mat.push_back(this->r_vec);
		vec_mat.push_back(this->t_vec);
		return vec_mat;
	}

	void PoseEstimator::draw_axes(Mat &img, Mat_<float> &R, Mat_<float> &t)
	{
		drawFrameAxes(img, this->camera_matrix, this->dist_coeffs, R, t, 100.0f);
	}

	Mat_<float> PoseEstimator::_get_full_model_points(std::string filename)
	{

		std::vector<float> vec_temp;
		float temp;

		std::ifstream model_file;
		model_file.open(filename, std::ios::in);
		if (!model_file)
		{
			std::cout << "Can not open the camera file." << std::endl;
		}
		else
		{
			std::cout << "Succeed open the camera file." << std::endl;
		}

		while (model_file)
		{
			model_file >> temp;
			vec_temp.push_back(temp);
		}
		vec_temp.pop_back();

		Mat_<float> model_pts(vec_temp);
		model_pts = model_pts.reshape(0, 3);
		model_pts = model_pts.t();
		model_pts(Range(0, model_pts.size().height), Range(2, 3)) = model_pts(Range(0, model_pts.size().height), Range(2, 3)) * -1.f;
		return model_pts;
	}

	//KalmanFilterForPoints::KalmanFilterForPoints(int state_num, int measure_num, float cov_process, float cov_measure)
	//{
	//	this->KF = new KalmanFilter(state_num, measure_num, 0);

	//	// intialization of KF...
	//	if (measure_num == 2)
	//	{
	//		KF->transitionMatrix = Mat_<float>(4, 4) << 1, 0, 1, 0, 0, 1, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1;
	//	}
	//	if (measure_num == 1)
	//	{
	//		KF->transitionMatrix = Mat_<float>(2, 2) << 1, 1, 0, 1;
	//	}
	//	
	//	Mat_<float> measurement(2, 1); measurement.setTo(Scalar(0));

	//	//KF.statePre.at<float>(0) = mousePos.x;
	//	//KF.statePre.at<float>(1) = mousePos.y;
	//	//KF.statePre.at<float>(2) = 0;
	//	//KF.statePre.at<float>(3) = 0;
	//	setIdentity(KF->measurementMatrix);
	//	setIdentity(KF->processNoiseCov, Scalar::all(cov_process));
	//	setIdentity(KF->measurementNoiseCov, Scalar::all(cov_measure));
	//	setIdentity(KF->errorCovPost, Scalar::all(.1));
	//}

	//Mat KalmanFilterForPoints::update(Mat measurement)
	//{
	//	// First predict, to update the internal statePre variable
	//	Mat prediction = KF->predict();

	//	// The update phase 
	//	Mat estimated = KF->correct(measurement);

	//	return estimated;
	//}

//// -----------------------------------------------------------------
//// Utilities
//
//void
//randSeed(void) {
//	srand(time(0));
//}
//
//double
//unifRand(void) {
//	return rand() / double(RAND_MAX);
//}
//
//typedef double TimeStamp; // in seconds
//
//static const TimeStamp UndefinedTime = -1.0;
//
//// -----------------------------------------------------------------
//
//class LowPassFilter {
//
//	double y, a, s;
//	bool initialized;
//
//	void setAlpha(double alpha) {
//		if (alpha <= 0.0 || alpha > 1.0)
//			throw std::range_error("alpha should be in (0.0., 1.0]");
//		a = alpha;
//	}
//
//public:
//
//	LowPassFilter(double alpha, double initval = 0.0) {
//		y = s = initval;
//		setAlpha(alpha);
//		initialized = false;
//	}
//
//	double filter(double value) {
//		double result;
//		if (initialized)
//			result = a * value + (1.0 - a)*s;
//		else {
//			result = value;
//			initialized = true;
//		}
//		y = value;
//		s = result;
//		return result;
//	}
//
//	double filterWithAlpha(double value, double alpha) {
//		setAlpha(alpha);
//		return filter(value);
//	}
//
//	bool hasLastRawValue(void) {
//		return initialized;
//	}
//
//	double lastRawValue(void) {
//		return y;
//	}
//
//};
//
//// -----------------------------------------------------------------
//
//class OneEuroFilter {
//
//	double freq;
//	double mincutoff;
//	double beta_;
//	double dcutoff;
//	LowPassFilter *x;
//	LowPassFilter *dx;
//	TimeStamp lasttime;
//
//	double alpha(double cutoff) {
//		double te = 1.0 / freq;
//		double tau = 1.0 / (2 * CV_PI*cutoff);
//		return 1.0 / (1.0 + tau / te);
//	}
//
//	void setFrequency(double f) {
//		if (f <= 0) throw std::range_error("freq should be >0");
//		freq = f;
//	}
//
//	void setMinCutoff(double mc) {
//		if (mc <= 0) throw std::range_error("mincutoff should be >0");
//		mincutoff = mc;
//	}
//
//	void setBeta(double b) {
//		beta_ = b;
//	}
//
//	void setDerivateCutoff(double dc) {
//		if (dc <= 0) throw std::range_error("dcutoff should be >0");
//		dcutoff = dc;
//	}
//
//public:
//
//	OneEuroFilter(double freq,
//		double mincutoff = 1.0, double beta_ = 0.0, double dcutoff = 1.0) {
//		setFrequency(freq);
//		setMinCutoff(mincutoff);
//		setBeta(beta_);
//		setDerivateCutoff(dcutoff);
//		x = new LowPassFilter(alpha(mincutoff));
//		dx = new LowPassFilter(alpha(dcutoff));
//		lasttime = UndefinedTime;
//	}
//
//	double filter(double value, TimeStamp timestamp = UndefinedTime) {
//		// update the sampling frequency based on timestamps
//		if (lasttime != UndefinedTime && timestamp != UndefinedTime)
//			freq = 1.0 / (timestamp - lasttime);
//		lasttime = timestamp;
//		// estimate the current variation per second 
//		double dvalue = x->hasLastRawValue() ? (value - x->lastRawValue())*freq : 0.0; // FIXME: 0.0 or value?
//		double edvalue = dx->filterWithAlpha(dvalue, alpha(dcutoff));
//		// use it to update the cutoff frequency
//		double cutoff = mincutoff + beta_ * fabs(edvalue);
//		// filter the given value
//		return x->filterWithAlpha(value, alpha(cutoff));
//	}
//
//	~OneEuroFilter(void) {
//		delete x;
//		delete dx;
//	}
//
};
